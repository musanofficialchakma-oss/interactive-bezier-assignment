// Bézier Curve with Physics Simulation
class Vector2 {
    constructor(x, y) {
        this.x = x || 0;
        this.y = y || 0;
    }

    add(v) {
        return new Vector2(this.x + v.x, this.y + v.y);
    }

    subtract(v) {
        return new Vector2(this.x - v.x, this.y - v.y);
    }

    multiply(scalar) {
        return new Vector2(this.x * scalar, this.y * scalar);
    }

    magnitude() {
        return Math.sqrt(this.x * this.x + this.y * this.y);
    }

    normalize() {
        const mag = this.magnitude();
        if (mag === 0) return new Vector2(0, 0);
        return new Vector2(this.x / mag, this.y / mag);
    }

    clone() {
        return new Vector2(this.x, this.y);
    }
}

class Point {
    constructor(x, y) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(0, 0);
        this.acceleration = new Vector2(0, 0);
    }

    update(dt) {
        this.velocity = this.velocity.add(this.acceleration.multiply(dt));
        this.position = this.position.add(this.velocity.multiply(dt));
        this.acceleration = new Vector2(0, 0);
    }

    applyForce(force) {
        this.acceleration = this.acceleration.add(force);
    }
}

class SpringPoint extends Point {
    constructor(x, y, stiffness, damping) {
        super(x, y);
        this.target = new Vector2(x, y);
        this.stiffness = stiffness; // Spring constant (k)
        this.damping = damping;    // Damping coefficient
    }

    updateSpringForce() {
        // Hooke's law with damping: F = -k(x - x0) - b*v
        const displacement = this.position.subtract(this.target);
        const springForce = displacement.multiply(-this.stiffness);
        const dampingForce = this.velocity.multiply(-this.damping);
        const force = springForce.add(dampingForce);
        this.applyForce(force);
    }
}

class CubicBezierCurve {
    constructor(p0, p1, p2, p3) {
        this.p0 = p0; // Fixed endpoint
        this.p1 = p1; // Dynamic control point
        this.p2 = p2; // Dynamic control point
        this.p3 = p3; // Fixed endpoint
    }

    // Calculate point on Bézier curve at parameter t
    getPoint(t) {
        const oneMinusT = 1 - t;
        const oneMinusTSquared = oneMinusT * oneMinusT;
        const oneMinusTCubed = oneMinusTSquared * oneMinusT;
        const tSquared = t * t;
        const tCubed = tSquared * t;

        // B(t) = (1−t)³P₀ + 3(1−t)²tP₁ + 3(1−t)t²P₂ + t³P₃
        const x = oneMinusTCubed * this.p0.position.x +
                  3 * oneMinusTSquared * t * this.p1.position.x +
                  3 * oneMinusT * tSquared * this.p2.position.x +
                  tCubed * this.p3.position.x;

        const y = oneMinusTCubed * this.p0.position.y +
                  3 * oneMinusTSquared * t * this.p1.position.y +
                  3 * oneMinusT * tSquared * this.p2.position.y +
                  tCubed * this.p3.position.y;

        return new Vector2(x, y);
    }

    // Calculate tangent (derivative) at parameter t
    getTangent(t) {
        const oneMinusT = 1 - t;
        const oneMinusTSquared = oneMinusT * oneMinusT;
        const tSquared = t * t;

        // B′(t) = 3(1−t)²(P₁−P₀) + 6(1−t)t(P₂−P₁) + 3t²(P₃−P₂)
        const tangentX = 3 * oneMinusTSquared * (this.p1.position.x - this.p0.position.x) +
                         6 * oneMinusT * t * (this.p2.position.x - this.p1.position.x) +
                         3 * tSquared * (this.p3.position.x - this.p2.position.x);

        const tangentY = 3 * oneMinusTSquared * (this.p1.position.y - this.p0.position.y) +
                         6 * oneMinusT * t * (this.p2.position.y - this.p1.position.y) +
                         3 * tSquared * (this.p3.position.y - this.p2.position.y);

        return new Vector2(tangentX, tangentY);
    }

    // Calculate curvature at parameter t (for advanced visualization)
    getCurvature(t) {
        // First derivative
        const d1 = this.getTangent(t);
        
        // Second derivative
        const oneMinusT = 1 - t;
        const tTimes2 = 2 * t;
        
        const d2x = 6 * oneMinusT * (this.p0.position.x - 2 * this.p1.position.x + this.p2.position.x) +
                   6 * t * (this.p1.position.x - 2 * this.p2.position.x + this.p3.position.x);
        
        const d2y = 6 * oneMinusT * (this.p0.position.y - 2 * this.p1.position.y + this.p2.position.y) +
                   6 * t * (this.p1.position.y - 2 * this.p2.position.y + this.p3.position.y);
        
        const d2 = new Vector2(d2x, d2y);
        
        // Curvature formula: κ = |d1 × d2| / |d1|³
        const cross = d1.x * d2.y - d1.y * d2.x;
        const magD1 = d1.magnitude();
        
        if (magD1 === 0) return 0;
        
        return Math.abs(cross) / Math.pow(magD1, 3);
    }
}

class BezierCurveApp {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.width = this.canvas.width;
        this.height = this.canvas.height;

        // Create fixed endpoints
        this.fixedP0 = new Point(100, this.height / 2);
        this.fixedP3 = new Point(this.width - 100, this.height / 2);

        // Create dynamic control points with spring physics
        this.dynamicP1 = new SpringPoint(
            this.width / 3, 
            this.height / 3, 
            0.1,  // stiffness
            0.15  // damping
        );
        
        this.dynamicP2 = new SpringPoint(
            2 * this.width / 3, 
            2 * this.height / 3, 
            0.1,  // stiffness
            0.15  // damping
        );

        // Create the Bézier curve
        this.bezierCurve = new CubicBezierCurve(
            this.fixedP0,
            this.dynamicP1,
            this.dynamicP2,
            this.fixedP3
        );

        // Visualization parameters
        this.curveThickness = 3;
        this.tangentLength = 30;
        this.showTangents = true;
        this.showControlPolygon = true;

        // Interaction state
        this.dragging = false;
        this.dragPoint = null;

        // Animation
        this.lastTime = 0;
        this.fps = 0;
        this.frameCount = 0;
        this.lastFpsUpdate = 0;

        // Set up event listeners
        this.setupEventListeners();
        this.setupUIControls();

        // Start animation loop
        requestAnimationFrame((time) => this.animate(time));
    }

    setupEventListeners() {
        this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.canvas.addEventListener('mouseup', () => this.handleMouseUp());
        this.canvas.addEventListener('mouseleave', () => this.handleMouseUp());

        // Touch events for mobile
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.canvas.dispatchEvent(mouseEvent);
        });

        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.canvas.dispatchEvent(mouseEvent);
        });

        this.canvas.addEventListener('touchend', (e) => {
            e.preventDefault();
            const mouseEvent = new MouseEvent('mouseup', {});
            this.canvas.dispatchEvent(mouseEvent);
        });
    }

    setupUIControls() {
        // Physics parameters
        const stiffnessSlider = document.getElementById('stiffness');
        const dampingSlider = document.getElementById('damping');
        const stiffnessValue = document.getElementById('stiffness-value');
        const dampingValue = document.getElementById('damping-value');
        
        // Visualization parameters
        const thicknessSlider = document.getElementById('curve-thickness');
        const tangentSlider = document.getElementById('tangent-length');
        const thicknessValue = document.getElementById('thickness-value');
        const lengthValue = document.getElementById('length-value');
        
        // FPS counter
        this.fpsElement = document.getElementById('fps-counter');

        if (stiffnessSlider) {
            stiffnessSlider.addEventListener('input', (e) => {
                const value = parseFloat(e.target.value);
                this.dynamicP1.stiffness = value;
                this.dynamicP2.stiffness = value;
                stiffnessValue.textContent = value.toFixed(2);
            });
        }

        if (dampingSlider) {
            dampingSlider.addEventListener('input', (e) => {
                const value = parseFloat(e.target.value);
                this.dynamicP1.damping = value;
                this.dynamicP2.damping = value;
                dampingValue.textContent = value.toFixed(2);
            });
        }

        if (thicknessSlider) {
            thicknessSlider.addEventListener('input', (e) => {
                this.curveThickness = parseFloat(e.target.value);
                thicknessValue.textContent = e.target.value;
            });
        }

        if (tangentSlider) {
            tangentSlider.addEventListener('input', (e) => {
                this.tangentLength = parseFloat(e.target.value);
                lengthValue.textContent = e.target.value;
            });
        }
    }

    getMousePos(e) {
        const rect = this.canvas.getBoundingClientRect();
        return new Vector2(
            e.clientX - rect.left,
            e.clientY - rect.top
        );
    }

    handleMouseDown(e) {
        const mousePos = this.getMousePos(e);
        
        // Check if we're clicking on a control point
        const points = [this.dynamicP1, this.dynamicP2];
        for (let point of points) {
            const distance = point.position.subtract(mousePos).magnitude();
            if (distance < 20) { // 20px radius for grabbing
                this.dragging = true;
                this.dragPoint = point;
                break;
            }
        }
    }

    handleMouseMove(e) {
        if (this.dragging && this.dragPoint) {
            const mousePos = this.getMousePos(e);
            this.dragPoint.target = mousePos.clone();
        }
    }

    handleMouseUp() {
        this.dragging = false;
        this.dragPoint = null;
    }

    updatePhysics(dt) {
        // Update spring forces for dynamic control points
        this.dynamicP1.updateSpringForce();
        this.dynamicP2.updateSpringForce();

        // Update positions based on forces
        this.dynamicP1.update(dt);
        this.dynamicP2.update(dt);
    }

    render() {
        // Clear canvas with a subtle gradient
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.height);
        gradient.addColorStop(0, 'rgba(240, 240, 255, 0.9)');
        gradient.addColorStop(1, 'rgba(220, 220, 255, 0.9)');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.width, this.height);

        // Draw the Bézier curve
        this.drawCurve();

        // Draw control points
        this.drawControlPoints();

        // Draw tangent vectors
        if (this.showTangents) {
            this.drawTangents();
        }

        // Draw FPS counter
        this.drawFPS();
    }

    drawCurve() {
        this.ctx.beginPath();
        this.ctx.lineWidth = this.curveThickness;
        this.ctx.strokeStyle = '#2196F3';
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';

        // Sample the curve at small t increments
        const step = 0.01;
        let point = this.bezierCurve.getPoint(0);
        this.ctx.moveTo(point.x, point.y);

        for (let t = step; t <= 1; t += step) {
            point = this.bezierCurve.getPoint(t);
            this.ctx.lineTo(point.x, point.y);
        }

        this.ctx.stroke();

        // Draw a subtle glow effect
        this.ctx.shadowColor = 'rgba(33, 150, 243, 0.5)';
        this.ctx.shadowBlur = 10;
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;
    }

    drawControlPoints() {
        // Draw lines connecting control points
        if (this.showControlPolygon) {
            this.ctx.beginPath();
            this.ctx.setLineDash([5, 5]); // Dashed line
            this.ctx.lineWidth = 1;
            this.ctx.strokeStyle = '#9E9E9E';
            this.ctx.moveTo(this.fixedP0.position.x, this.fixedP0.position.y);
            this.ctx.lineTo(this.dynamicP1.position.x, this.dynamicP1.position.y);
            this.ctx.lineTo(this.dynamicP2.position.x, this.dynamicP2.position.y);
            this.ctx.lineTo(this.fixedP3.position.x, this.fixedP3.position.y);
            this.ctx.stroke();
            this.ctx.setLineDash([]); // Reset to solid line
        }

        // Draw fixed endpoints
        this.drawPoint(this.fixedP0.position, '#4CAF50', 8); // Green
        this.drawPoint(this.fixedP3.position, '#4CAF50', 8); // Green

        // Draw dynamic control points
        this.drawPoint(this.dynamicP1.position, '#FF5722', 12); // Orange
        this.drawPoint(this.dynamicP2.position, '#FF5722', 12); // Orange

        // Draw labels for control points
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillStyle = '#333';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText('P₀', this.fixedP0.position.x, this.fixedP0.position.y - 20);
        this.ctx.fillText('P₁', this.dynamicP1.position.x, this.dynamicP1.position.y - 20);
        this.ctx.fillText('P₂', this.dynamicP2.position.x, this.dynamicP2.position.y - 20);
        this.ctx.fillText('P₃', this.fixedP3.position.x, this.fixedP3.position.y - 20);
    }

    drawPoint(position, color, radius) {
        this.ctx.beginPath();
        this.ctx.arc(position.x, position.y, radius, 0, Math.PI * 2);
        this.ctx.fillStyle = color;
        this.ctx.fill();
        this.ctx.strokeStyle = '#FFFFFF';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
    }

    drawTangents() {
        this.ctx.strokeStyle = '#9C27B0';
        this.ctx.lineWidth = 2;

        // Draw tangent vectors at several points along the curve
        const tangentPoints = [0.2, 0.4, 0.6, 0.8];

        for (let t of tangentPoints) {
            const point = this.bezierCurve.getPoint(t);
            const tangent = this.bezierCurve.getTangent(t).normalize().multiply(this.tangentLength);

            // Draw the tangent line
            this.ctx.beginPath();
            this.ctx.moveTo(point.x, point.y);
            this.ctx.lineTo(point.x + tangent.x, point.y + tangent.y);
            this.ctx.stroke();

            // Draw arrowhead
            this.drawArrowhead(point, tangent);

            // Draw curvature indicator
            const curvature = this.bezierCurve.getCurvature(t);
            const radius = Math.min(Math.max(curvature * 1000, 5), 20);
            
            this.ctx.beginPath();
            this.ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
            this.ctx.fillStyle = 'rgba(156, 39, 176, 0.3)';
            this.ctx.fill();
        }
    }

    drawArrowhead(point, tangent) {
        const angle = Math.atan2(tangent.y, tangent.x);
        const arrowSize = 8;

        this.ctx.beginPath();
        this.ctx.moveTo(point.x + tangent.x, point.y + tangent.y);
        this.ctx.lineTo(
            point.x + tangent.x - arrowSize * Math.cos(angle - Math.PI / 6),
            point.y + tangent.y - arrowSize * Math.sin(angle - Math.PI / 6)
        );
        this.ctx.lineTo(
            point.x + tangent.x - arrowSize * Math.cos(angle + Math.PI / 6),
            point.y + tangent.y - arrowSize * Math.sin(angle + Math.PI / 6)
        );
        this.ctx.closePath();
        this.ctx.fillStyle = '#9C27B0';
        this.ctx.fill();
    }

    drawFPS() {
        if (this.fpsElement) {
            this.fpsElement.textContent = Math.round(this.fps);
        } else {
            this.ctx.font = '14px Arial';
            this.ctx.fillStyle = '#333';
            this.ctx.fillText(`FPS: ${Math.round(this.fps)}`, 10, 20);
        }
    }

    calculateFPS(timestamp) {
        this.frameCount++;
        const elapsed = timestamp - this.lastFpsUpdate;
        
        if (elapsed >= 1000) { // Update FPS every second
            this.fps = (this.frameCount * 1000) / elapsed;
            this.frameCount = 0;
            this.lastFpsUpdate = timestamp;
        }
    }

    animate(timestamp) {
        // Calculate delta time in seconds
        const dt = Math.min((timestamp - this.lastTime) / 1000, 0.016); // Cap at 60fps (0.016s)
        this.lastTime = timestamp;

        // Update FPS counter
        this.calculateFPS(timestamp);

        // Update physics
        this.updatePhysics(dt);

        // Render everything
        this.render();

        // Continue animation loop
        requestAnimationFrame((time) => this.animate(time));
    }
}

// Initialize the app when the page loads
window.addEventListener('load', () => {
    new BezierCurveApp('bezierCanvas');
});