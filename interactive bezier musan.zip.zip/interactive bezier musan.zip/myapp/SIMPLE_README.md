# Simple Bézier Curve Visualization

## Overview

This is a minimalist implementation of a cubic Bézier curve visualization that focuses on the core mathematical concepts without complex physics or advanced visual effects.

## Features

1. **Clean Visualization**:
   - Clear rendering of the Bézier curve
   - Visible control polygon connecting all control points
   - Labeled control points (P0, P1, P2, P3)

2. **Interactive Controls**:
   - Draggable control points (P1 and P2)
   - Sliders for adjusting curve parameters
   - Real-time updating of the curve

3. **Adjustable Parameters**:
   - Curve segments (resolution): 10-200 segments
   - Line width: 1-10 pixels

4. **Responsive Design**:
   - Works on both desktop and mobile devices
   - Touch support for mobile interaction

## Mathematical Implementation

### Bézier Curve Formula

The cubic Bézier curve is calculated using the standard parametric equation:

```
B(t) = (1−t)³P₀ + 3(1−t)²tP₁ + 3(1−t)t²P₂ + t³P₃
```

Where:
- P₀ and P₃ are fixed endpoints
- P₁ and P₂ are draggable control points
- t ranges from 0 to 1

### Implementation Details

1. **Point Calculation**:
   - For each value of t from 0 to 1, calculate the corresponding point on the curve
   - Connect all points to form the curve

2. **Control Polygon**:
   - Lines connecting P₀→P₁→P₂→P₃ shown as dashed lines
   - Helps visualize how control points affect the curve

3. **Interaction**:
   - Click and drag P₁ or P₂ to modify the curve shape
   - Sliders provide precise control over parameters

## Technical Details

### File Structure
- `simple-bezier.html`: Single HTML file containing all code
- No external dependencies
- Vanilla JavaScript implementation

### Browser Support
- All modern browsers with HTML5 Canvas support
- Mobile browsers with touch support

### Performance
- Efficient rendering using canvas path drawing
- Optimized point calculations
- Smooth interaction with requestAnimationFrame

## Usage Instructions

1. Open `simple-bezier.html` in a web browser
2. Drag the orange control points (P1 and P2) to modify the curve
3. Use sliders to adjust:
   - Curve resolution (more segments = smoother curve)
   - Line thickness
4. Observe how changes to control points affect the curve shape

## Educational Value

This implementation clearly demonstrates:
- How control points influence curve shape
- The mathematical relationship between control points and the curve
- Parametric equations in computer graphics
- Basic HTML5 Canvas drawing techniques
- Client-side interactivity with JavaScript

## Comparison to Other Implementations

Unlike the other versions in this project:
- No complex physics simulation
- No particle systems
- No advanced visual effects
- Focuses purely on the mathematical concept
- Minimalist interface for clearer learning

This simplicity makes it ideal for understanding the fundamental principles of Bézier curves.