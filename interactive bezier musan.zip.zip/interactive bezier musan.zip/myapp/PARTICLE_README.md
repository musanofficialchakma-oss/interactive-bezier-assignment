# Particle-Based Bézier Curve Simulation

## Overview

This implementation presents a completely different approach to visualizing Bézier curves by using a particle system instead of direct curve rendering. Particles flow along the curve path, creating a dynamic, fluid visualization that responds to physics parameters in real-time.

## Key Differences from Traditional Approach

1. **Particle System Visualization**:
   - Hundreds of particles flow along the Bézier curve path
   - Particles leave colored trails that visualize the curve's motion
   - Connections form between nearby particles for a web-like effect

2. **Verlet Integration Physics**:
   - Uses Verlet integration for smoother, more stable physics
   - Particles naturally follow the curve with spring forces
   - Organic noise creates natural-looking movement

3. **Interactive Control Points**:
   - Four control points (two fixed, two dynamic)
   - Dynamic points exhibit spring physics when dragged
   - Gravity effect can be applied to create drooping curves

## Features

### Physics Controls
- **Stiffness**: Controls how strongly particles are pulled to the curve
- **Damping**: Controls how quickly oscillations decay
- **Gravity**: Applies downward force to create hanging curve effects

### Particle System
- **Particle Count**: Adjust the number of particles (50-500)
- **Particle Size**: Change the size of individual particles
- **Connection Distance**: Set how close particles need to be to form connections

### Visualization
- **Trail Length**: Control how long particle trails persist
- **Glow Intensity**: Adjust the glowing effect around particles
- **Reset/Randimize**: Buttons to reset or randomize the simulation

## Mathematical Implementation

### Bézier Curve Calculation
The cubic Bézier curve is calculated using the standard parametric equation:
```
B(t) = (1−t)³P₀ + 3(1−t)²tP₁ + 3(1−t)t²P₂ + t³P₃
```

### Verlet Integration
Instead of Euler integration, we use Verlet integration for more stable physics:
```
x(t+Δt) = 2x(t) - x(t-Δt) + a(t)Δt²
```

### Spring Forces
Particles are attracted to their target positions on the curve:
```
F = -k(x - target)
```

## Technical Architecture

### Core Classes

1. **Vector2**: 2D vector mathematics utility
2. **Particle**: Individual particle with position, velocity, and trail
3. **ControlPoint**: Interactive control point with physics properties
4. **ParticleBezierSimulation**: Main simulation controller

### Rendering Pipeline

1. Clear canvas with dark background
2. Update particle positions based on physics
3. Draw connections between nearby particles
4. Render particle trails and particles
5. Draw control points and control polygon

## Performance Optimizations

- Efficient Verlet integration reduces computational overhead
- Spatial partitioning concept for particle connections
- Trail rendering optimized with array shifting
- RequestAnimationFrame for smooth 60 FPS rendering
- Canvas clipping for particles outside viewport

## Interaction Guide

1. **Drag Control Points**: Click and drag the blue dynamic control points
2. **Adjust Physics**: Use sliders to change stiffness, damping, and gravity
3. **Modify Particles**: Change particle count, size, and connection distance
4. **Visual Effects**: Adjust trail length and glow intensity
5. **Reset Simulation**: Use buttons to reset or randomize the curve

## Educational Value

This implementation demonstrates:
- Advanced particle system techniques
- Verlet integration for physics simulation
- Real-time parameter adjustment
- Complex rendering optimization
- Mathematical curve visualization through emergent behavior

## Browser Compatibility

- Modern browsers supporting HTML5 Canvas
- JavaScript ES6 features
- Touch support for mobile devices
- Responsive design for various screen sizes

## File Structure

```
particle-bezier.html    # Main HTML file with embedded JavaScript
PARTICLE_README.md      # This documentation file
```

The implementation is contained in a single HTML file for easy execution.