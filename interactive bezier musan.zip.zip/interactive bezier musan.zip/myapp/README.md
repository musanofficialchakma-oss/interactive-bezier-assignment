# Interactive Bézier Curve with Physics & Sensor Control

## Overview

This project implements an interactive cubic Bézier curve that behaves like a rope reacting to mouse movements. The curve dynamically responds to user input with realistic spring physics and visualizes tangent vectors along its path.

## Enhanced Features

1. **Advanced Bézier Curve Mathematics**:
   - Implemented the parametric equation: B(t) = (1−t)³P₀ + 3(1−t)²tP₁ + 3(1−t)t²P₂ + t³P₃
   - Calculated tangent vectors using the derivative: B′(t) = 3(1−t)²(P₁−P₀) + 6(1−t)t(P₂−P₁) + 3t²(P₃−P₂)
   - Computed curvature for advanced visualization

2. **Realistic Physics Simulation**:
   - Spring-damping model for natural motion: acceleration = −k × (position − target) − damping × velocity
   - Real-time physics updates for responsive interaction
   - Adjustable stiffness and damping parameters

3. **Rich Visualization**:
   - Rendered Bézier curve path with glow effect
   - Visualized control points (fixed endpoints in green, dynamic points in orange)
   - Displayed tangent vectors with directional arrows
   - Curvature visualization at tangent points
   - Control polygon connections shown with dashed lines
   - Labeled control points (P₀, P₁, P₂, P₃)

4. **Interactive Controls**:
   - Mouse/touch controls for manipulating dynamic control points
   - Smooth spring-based animation when releasing control points
   - Adjustable visualization parameters (curve thickness, tangent length)
   - Real-time physics parameter adjustment
   - Responsive design that works on both desktop and mobile devices

5. **Polished UI**:
   - Modern gradient background
   - Intuitive control panels
   - Real-time FPS monitoring
   - Color-coded legend
   - Interactive sliders for all parameters

## Implementation Details

### Mathematical Foundation

The cubic Bézier curve is defined by four control points:
- P₀ and P₃: Fixed endpoints
- P₁ and P₂: Dynamic control points that respond to user input

The curve is computed using the parametric equation with t ranging from 0 to 1 in small increments (0.01) for smooth rendering.

### Physics Model

The spring-damping system simulates realistic rope-like behavior:
- Stiffness (k): Controls how strongly the point is pulled toward its target
- Damping (b): Controls how quickly oscillations decay
- Force calculation: F = -k(x - x₀) - bv

### Technical Architecture

The code is organized into clean, modular components:
1. **Vector2**: 2D vector mathematics utility
2. **Point/SpringPoint**: Physics-enabled point classes
3. **CubicBezierCurve**: Bézier curve mathematics implementation with curvature calculation
4. **BezierCurveApp**: Main application controller handling rendering, physics, and interaction

## Running the Application

1. Serve the files using any HTTP server:
   ```
   python -m http.server 8000
   ```
2. Open `http://localhost:8000` in your browser
3. Click and drag the orange control points to manipulate the curve
4. Use the control panels to adjust physics and visualization parameters

## Performance Optimization

- Efficient rendering using HTML Canvas with gradient backgrounds
- Optimized animation loop with requestAnimationFrame
- Frame rate monitoring displayed in the UI
- Controlled physics timestep to maintain stability
- Efficient vector mathematics implementation

## Browser Support

- Modern browsers supporting HTML5 Canvas and ECMAScript 6
- Touch support for mobile devices
- Responsive design for various screen sizes

## Screen Recording Demonstration

A demo script is included in `demo_script.txt` that shows how to demonstrate all features of the application in a 50-second screen recording.